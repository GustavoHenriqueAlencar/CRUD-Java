/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projetobiblioteca;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Gustavo33297826
 */
public class ProjetoBiblioteca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {

        UsuarioDao dao = new UsuarioDao();
        Usuario usuarioDeletar = new Usuario();

        usuarioDeletar.setId(11);

        dao.deletarUsuario(usuarioDeletar);

        //  Usuario usuarioCriar = new Usuario(0, "Marcelo", "Marcelo@mail", "99999999", "Marcelado");
        // dao.criarUsuario(usuarioCriar);
        /*
          Connection connection = null;
         try {

            connection = new ConnectionFactory().conectaDB();

            UsuarioDao usuarioDAO = new UsuarioDao();

            // Usuario usuario = new Usuario(0, "Marcela", "marcela@mail", "40028922", "Maluca");
            // usuarioDAO.criarUsuario(usuario)';
            Usuario usuarioAtualizado = new Usuario();

            usuarioAtualizado.setNome("Marcel�o");
            usuarioAtualizado.setEmail("marcelao@mail");
            usuarioAtualizado.setTelefone("4002-8922");
            usuarioAtualizado.setTipo_usuario("Kennan e Kel");
            usuarioAtualizado.setId(1);

            usuarioDAO.atualizarUsuario(usuarioAtualizado);

        } catch (SQLException e) {
            System.out.println("Erro na opera��o" + e.getMessage());

        } finally {

            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.out.println("Erro ao fechar conex�o: " + e.getMessage());
            }

        }

        /*
        try {
            List<Usuario> usuarios = usuarioDAO.listarUsuarios();

            Usuario usrId = usuarioDAO.buscarUsuarioPorId(2);

            if (usrId != null) {
                System.out.println("id: " + usrId.getId());
                System.out.println("nome: " + usrId.getNome());
                System.out.println("email: " + usrId.getEmail());
                System.out.println("telefone: " + usrId.getTelefone());
                System.out.println("tipo_usuario: " + usrId.getTipo_usuario());
                System.out.println("======================//");
            } else {
                System.out.println("Id n�o encontrado!");
            }
            

            if (usuarios.isEmpty()) {
                System.out.println("Ninguem no banco");
            } else {

                for (Usuario usuario : usuarios) {

                    System.out.println("id: " + usuario.getId());
                    System.out.println("nome: " + usuario.getNome());
                    System.out.println("email: " + usuario.getEmail());
                    System.out.println("telefone: " + usuario.getTelefone());
                    System.out.println("tipo_usuario: " + usuario.getTipo_usuario());
                    System.out.println("======================//");

                }

            }

        } catch (SQLException e) {
            System.out.println("Deu ruim " + e.getMessage());
        }
         */
    }

}
